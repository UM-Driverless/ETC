/* 
 * File:   PARAMETERS.c
 * Author: 93Urbano
 *
 * Created on December 4, 2021, 2:24 PM
 */


#include "../ETC.X/PARAMETERS.h"